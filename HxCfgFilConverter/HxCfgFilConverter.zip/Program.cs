﻿using HXCFGFILLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if(args.Length != 3)
            {
                Console.WriteLine("Usage: HxCfgFilConverter file <option> output");
                Console.WriteLine("Options:");
                Console.WriteLine("\tascii - convert file to ascii");
                Console.WriteLine("\tbinary - convert file to binary");
                return;
            }
            bool toAscii = args[1].Equals("ascii", StringComparison.OrdinalIgnoreCase);
            string source = args[0];
            string output = args[2];
            var cfg = new HxCfgFile();
            cfg.LoadFile(source);
            if(toAscii) 
                cfg.StoreFile(output, 0);
            else
                cfg.SerializeFile(output, 0);
        }
    }
}
